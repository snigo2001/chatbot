import sqlite3

# Conexión o creación de la base de datos
conn = sqlite3.connect("chatbot_pop.db")
cursor = conn.cursor()

# Crear tabla si no existe
cursor.execute("""
CREATE TABLE IF NOT EXISTS conocimiento (
    pregunta TEXT PRIMARY KEY,
    respuesta TEXT
)
""")
conn.commit()

print("🎬 Bienvenido al Chatbot de Cultura Pop (Base de datos activada). Escribe 'salir' para terminar.")

while True:
    entrada = input("Tú: ").strip().lower()
    
    if entrada == "salir":
        print("🧠 Chatbot: ¡Hasta la próxima! Sigue disfrutando la cultura pop.")
        break

    # Buscar en la base de datos
    cursor.execute("SELECT respuesta FROM conocimiento WHERE pregunta = ?", (entrada,))
    resultado = cursor.fetchone()

    if resultado:
        print("🧠 Chatbot:", resultado[0])
    else:
        print("🧠 Chatbot: No sé eso todavía. ¿Cuál sería una buena respuesta?")
        nueva_respuesta = input("Tú (respuesta): ").strip()

        # Insertar en la base de datos
        try:
            cursor.execute("INSERT INTO conocimiento (pregunta, respuesta) VALUES (?, ?)", (entrada, nueva_respuesta))
            conn.commit()
            print("✅ ¡Gracias! Aprendí algo nuevo.")
        except sqlite3.IntegrityError:
            print("⚠️ Ya tenía esa pregunta registrada.")

# Cierra la conexión al terminar
conn.close()
