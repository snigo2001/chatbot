import sqlite3
import wikipedia

# Configuración de Wikipedia en español
wikipedia.set_lang("es")

# Conexión a la base de datos
conn = sqlite3.connect("chatbot_pop.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS conocimiento (
    categoria TEXT,
    pregunta TEXT PRIMARY KEY,
    respuesta TEXT
)
""")
conn.commit()

def mostrar_categorias():
    print("\n🎭 Categorías disponibles:")
    print("1. Libros")
    print("2. Películas")
    print("3. Series")
    print("4. Cómics")
    print("5. Manga")
    print("6. Música")
    print("7. Figuras importantes")
    print("8. General")

def obtener_categoria(opcion):
    categorias = {
        "1": "libros",
        "2": "películas",
        "3": "series",
        "4": "cómics",
        "5": "manga",
        "6": "música",
        "7": "figuras importantes",
        "8": "general"
    }
    return categorias.get(opcion, "general")

print("🎬 Bienvenido al Chatbot de Cultura Pop por categorías.")
print("Escribe 'salir' en cualquier momento para terminar.")

while True:
    mostrar_categorias()
    opcion = input("\nElige una categoría (1-8): ").strip()
    if opcion.lower() == "salir":
        break

    categoria = obtener_categoria(opcion)

    pregunta = input(f"\n🔎 ¿Qué quieres saber sobre {categoria}? ").strip().lower()
    if pregunta == "salir":
        break

    # Buscar en la base de datos local
    cursor.execute("SELECT respuesta FROM conocimiento WHERE pregunta = ?", (pregunta,))
    resultado = cursor.fetchone()

    if resultado:
        print(f"🤖 Chatbot ({categoria} - local):", resultado[0])
    else:
        try:
            resumen = wikipedia.summary(pregunta, sentences=2)
            print(f"🤖 Chatbot ({categoria} - Wikipedia):", resumen)
        except wikipedia.exceptions.DisambiguationError as e:
            print("⚠️ Tu pregunta es ambigua. Intenta ser más específico.")
            print("🔎 Algunas opciones:", ", ".join(e.options[:5]))
        except wikipedia.exceptions.PageError:
            print("❌ No encontré nada. ¿Quieres enseñarme la respuesta?")
            nueva_respuesta = input("Tú (respuesta): ").strip()
            cursor.execute("INSERT INTO conocimiento (categoria, pregunta, respuesta) VALUES (?, ?, ?)", 
                           (categoria, pregunta, nueva_respuesta))
            conn.commit()
            print("✅ ¡Gracias! Ahora sé más sobre eso.")
        except Exception as e:
            print("⚠️ Ocurrió un error al buscar en Wikipedia:", e)

conn.close()
print("👋 Chatbot cerrado. ¡Gracias por usar el sistema!")
