import sqlite3
import wikipedia
import re

# Configuración de Wikipedia en español
wikipedia.set_lang("es")

# Conexión a la base de datos
conn = sqlite3.connect("chatbot_pop.db")
cursor = conn.cursor()

# Crea la tabla con la columna 'categoria'
cursor.execute("""
CREATE TABLE IF NOT EXISTS conocimiento (
    categoria TEXT,
    pregunta TEXT PRIMARY KEY,
    respuesta TEXT
)
""")
conn.commit()

def mostrar_categorias():
    print("\n🎭 Categorías disponibles:")
    print("1. Libros")
    print("2. Películas")
    print("3. Series")
    print("4. Cómics")
    print("5. Manga")
    print("6. Música")
    print("7. Figuras importantes")
    print("8. General")

def obtener_categoria(opcion):
    categorias = {
        "1": "libros",
        "2": "películas",
        "3": "series",
        "4": "cómics",
        "5": "manga",
        "6": "música",
        "7": "figuras importantes",
        "8": "general"
    }
    return categorias.get(opcion, "general")

def limpiar_pregunta(pregunta):
    pregunta = pregunta.lower().strip()
    pregunta = re.sub(r"[¿?¡!.,]", "", pregunta)
    return pregunta

print("🎬 Bienvenido al Chatbot de Cultura Pop.")
print("Escribe 'salir' para terminar.")

while True:
    mostrar_categorias()
    opcion = input("\nElige una categoría (1-8): ").strip()
    if opcion.lower() == "salir":
        break

    categoria = obtener_categoria(opcion)

    pregunta = input(f"\n🔎 ¿Qué quieres saber sobre {categoria}? ").strip()
    if pregunta.lower() == "salir":
        break

    pregunta_limpia = limpiar_pregunta(pregunta)

    if not pregunta_limpia:
        print("⚠️ La pregunta está vacía o inválida. Intenta con otra.")
        continue

    # Buscar en la base de datos local
    cursor.execute("SELECT respuesta FROM conocimiento WHERE pregunta = ?", (pregunta_limpia,))
    resultado = cursor.fetchone()

    if resultado:
        print(f"🤖 Chatbot ({categoria} - local):", resultado[0])
    else:
        try:
            resumen = wikipedia.summary(pregunta, sentences=2, auto_suggest=True)
            print(f"🤖 Chatbot ({categoria} - Wikipedia):", resumen)
        except wikipedia.exceptions.DisambiguationError as e:
            print("⚠️ Tu pregunta es ambigua. Intenta ser más específico.")
            print("🔎 Algunas opciones:", ", ".join(e.options[:5]))
        except wikipedia.exceptions.PageError:
            print("❌ No encontré nada. ¿Quieres enseñarme la respuesta?")
            nueva_respuesta = input("Tú (respuesta): ").strip()
            cursor.execute(
                "INSERT INTO conocimiento (categoria, pregunta, respuesta) VALUES (?, ?, ?)",
                (categoria, pregunta_limpia, nueva_respuesta)
            )
            conn.commit()
            print("✅ ¡Gracias! Ahora sé más sobre eso.")
        except Exception as e:
            print("⚠️ Ocurrió un error al buscar en Wikipedia:", e)

conn.close()
print("👋 Chatbot cerrado. ¡Gracias por usarlo!")
